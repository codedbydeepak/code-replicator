import { Result } from "@shared/schema";
import { Globe, Building2, ExternalLink } from "lucide-react";

interface ResultTableProps {
  results: Result[];
  showFiltered: boolean;
  setShowFiltered: (show: boolean) => void;
}

export function ResultTable({ results, showFiltered, setShowFiltered }: ResultTableProps) {
  const includedResults = results.filter(r => !r.filtered);
  const excludedResults = results.filter(r => r.filtered);
  const displayResults = showFiltered ? excludedResults : includedResults;

  if (results.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center p-12 text-center border-2 border-dashed rounded-xl border-muted bg-slate-50/50">
        <div className="p-4 bg-white rounded-full shadow-sm">
          <Globe className="w-8 h-8 text-muted-foreground/50" />
        </div>
        <h3 className="mt-4 text-lg font-medium text-foreground">No results found yet</h3>
        <p className="mt-2 text-sm text-muted-foreground max-w-sm">
          Results will appear here as the scraper processes the Google Maps URL.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Tab buttons */}
      <div className="flex gap-2">
        <button
          onClick={() => setShowFiltered(false)}
          className={`px-4 py-2 rounded-lg font-medium transition-all ${
            !showFiltered
              ? "bg-blue-100 text-blue-700 border border-blue-200"
              : "bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-150"
          }`}
          data-testid="tab-included-results"
        >
          Results ({includedResults.length})
        </button>
        {excludedResults.length > 0 && (
          <button
            onClick={() => setShowFiltered(true)}
            className={`px-4 py-2 rounded-lg font-medium transition-all ${
              showFiltered
                ? "bg-amber-100 text-amber-700 border border-amber-200"
                : "bg-slate-100 text-slate-600 border border-slate-200 hover:bg-slate-150"
            }`}
            data-testid="tab-excluded-results"
          >
            Excluded ({excludedResults.length})
          </button>
        )}
      </div>

      {/* Table */}
      <div className="overflow-hidden border bg-card rounded-xl shadow-sm border-border/50">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead>
              <tr className="border-b bg-muted/30 border-border/50">
                <th className="px-6 py-4 font-semibold text-foreground w-[40%]">Place Name</th>
                <th className="px-6 py-4 font-semibold text-foreground">Website</th>
                <th className="px-6 py-4 font-semibold text-foreground w-[100px] text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/50">
              {displayResults.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-6 py-8 text-center text-muted-foreground">
                    No {showFiltered ? "excluded" : "results"} to display
                  </td>
                </tr>
              ) : (
                displayResults.map((result) => (
                  <tr 
                    key={result.id} 
                    className="group hover:bg-muted/30 transition-colors duration-150"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg group-hover:opacity-75 transition-colors ${
                          showFiltered
                            ? "bg-amber-50 text-amber-600"
                            : "bg-blue-50 text-blue-600"
                        }`}>
                          <Building2 className="w-4 h-4" />
                        </div>
                        <span className="font-medium text-foreground">{result.name}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      {result.website ? (
                        <a
                          href={result.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-muted-foreground hover:text-primary transition-colors group/link"
                        >
                          <span className="truncate max-w-[300px]">{result.website}</span>
                          <ExternalLink className="w-3 h-3 opacity-0 group-hover/link:opacity-100 transition-opacity" />
                        </a>
                      ) : (
                        <span className="text-muted-foreground/40 italic">No website available</span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-right">
                      {result.website && (
                        <a
                          href={result.website}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center justify-center w-8 h-8 rounded-lg hover:bg-blue-50 hover:text-blue-600 transition-colors text-muted-foreground"
                          title="Visit Website"
                        >
                          <ExternalLink className="w-4 h-4" />
                        </a>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
