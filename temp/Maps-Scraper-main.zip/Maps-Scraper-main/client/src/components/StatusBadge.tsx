import { Loader2, CheckCircle2, XCircle, Clock } from "lucide-react";
import { cn } from "@/lib/utils";

type Status = "pending" | "processing" | "completed" | "failed";

interface StatusBadgeProps {
  status: Status;
  className?: string;
}

export function StatusBadge({ status, className }: StatusBadgeProps) {
  const config = {
    pending: {
      icon: Clock,
      label: "Pending",
      styles: "bg-yellow-50 text-yellow-700 border-yellow-200",
    },
    processing: {
      icon: Loader2,
      label: "Processing",
      styles: "bg-blue-50 text-blue-700 border-blue-200",
      animate: true,
    },
    completed: {
      icon: CheckCircle2,
      label: "Completed",
      styles: "bg-green-50 text-green-700 border-green-200",
    },
    failed: {
      icon: XCircle,
      label: "Failed",
      styles: "bg-red-50 text-red-700 border-red-200",
    },
  };

  const { icon: Icon, label, styles, animate } = config[status] || config.pending;

  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border",
        styles,
        className
      )}
    >
      <Icon className={cn("w-3.5 h-3.5", animate && "animate-spin")} />
      {label}
    </span>
  );
}
