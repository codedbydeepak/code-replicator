import { useState } from "react";
import { useJobs, useCreateJob } from "@/hooks/use-jobs";
import { useLocation } from "wouter";
import { StatusBadge } from "@/components/StatusBadge";
import { 
  Search, 
  MapPin, 
  ArrowRight, 
  Sparkles, 
  Database, 
  History,
  AlertCircle
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Home() {
  const [url, setUrl] = useState("");
  const [, setLocation] = useLocation();
  const { data: jobs, isLoading: isLoadingJobs } = useJobs();
  const createJob = useCreateJob();
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;
    setError(null);

    try {
      // Basic client-side validation
      if (!url.includes("google.com/maps")) {
        throw new Error("Please enter a valid Google Maps URL");
      }

      const job = await createJob.mutateAsync({ url });
      setLocation(`/jobs/${job.id}`);
    } catch (err: any) {
      setError(err.message || "Failed to start scraping job");
    }
  };

  return (
    <div className="min-h-screen bg-slate-50/50">
      {/* Hero Section */}
      <div className="bg-white border-b pb-12 pt-16 md:pt-24 px-4 sm:px-6 lg:px-8 relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 -mt-20 -mr-20 w-96 h-96 bg-primary/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -mb-20 -ml-20 w-64 h-64 bg-accent/5 rounded-full blur-3xl pointer-events-none" />

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-sm font-medium mb-6 border border-blue-100 shadow-sm">
            <Sparkles className="w-4 h-4" />
            <span>Smart Google Maps Lead Extractor</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold font-display tracking-tight text-foreground mb-6">
            Turn Maps into <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Leads</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
            Extract business names and websites from any Google Maps search.
            Just paste the URL and we'll handle the scrolling, extraction, and CSV export.
          </p>

          <form onSubmit={handleSubmit} className="max-w-2xl mx-auto relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-primary to-accent rounded-2xl opacity-20 group-hover:opacity-30 transition duration-500 blur-lg"></div>
            <div className="relative flex flex-col sm:flex-row gap-3 p-2 bg-white rounded-xl shadow-xl ring-1 ring-slate-900/5">
              <div className="flex-1 relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <MapPin className="h-5 w-5 text-muted-foreground" />
                </div>
                <input
                  type="text"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="Paste Google Maps Search URL..."
                  className="block w-full pl-11 pr-4 py-4 sm:text-sm border-none rounded-lg bg-transparent focus:ring-0 placeholder:text-muted-foreground/50 text-foreground"
                />
              </div>
              <button
                type="submit"
                disabled={createJob.isPending}
                className="inline-flex items-center justify-center px-8 py-4 border border-transparent text-sm font-bold rounded-lg text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary shadow-lg shadow-primary/25 hover:shadow-xl hover:shadow-primary/30 transition-all duration-200 disabled:opacity-70 disabled:cursor-not-allowed"
              >
                {createJob.isPending ? "Starting..." : "Extract Leads"}
                <ArrowRight className="ml-2 w-4 h-4" />
              </button>
            </div>
          </form>

          {error && (
            <div className="mt-4 flex items-center justify-center gap-2 text-red-600 bg-red-50 py-2 px-4 rounded-lg inline-flex animate-in fade-in slide-in-from-top-2">
              <AlertCircle className="w-4 h-4" />
              <span className="text-sm font-medium">{error}</span>
            </div>
          )}
        </div>
      </div>

      {/* Recent Jobs Section */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white rounded-lg shadow-sm border border-slate-200">
              <History className="w-5 h-5 text-primary" />
            </div>
            <h2 className="text-xl font-bold font-display text-foreground">Recent Extractions</h2>
          </div>
          {jobs?.length ? (
            <div className="text-sm text-muted-foreground font-medium bg-white px-3 py-1 rounded-full border shadow-sm">
              {jobs.length} Total Jobs
            </div>
          ) : null}
        </div>

        {isLoadingJobs ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 rounded-2xl bg-slate-200/50 animate-pulse" />
            ))}
          </div>
        ) : jobs?.length === 0 ? (
          <div className="text-center py-20 bg-white rounded-3xl border border-dashed border-slate-300">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4 border border-slate-100 shadow-sm">
              <Database className="w-8 h-8 text-slate-300" />
            </div>
            <h3 className="text-lg font-medium text-slate-900">No jobs yet</h3>
            <p className="mt-1 text-slate-500 max-w-sm mx-auto">
              Paste a URL above to start your first scraping job.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {jobs?.map((job) => (
              <a
                key={job.id}
                href={`/jobs/${job.id}`}
                className="group block bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl hover:shadow-primary/5 hover:border-primary/50 transition-all duration-300 overflow-hidden relative"
              >
                <div className="absolute top-0 right-0 p-4 opacity-50 group-hover:opacity-100 transition-opacity">
                  <ArrowRight className="w-5 h-5 text-primary -translate-x-2 group-hover:translate-x-0 transition-transform" />
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <StatusBadge status={job.status as any} />
                    <span className="text-xs font-medium text-muted-foreground bg-slate-50 px-2 py-1 rounded-md border border-slate-100">
                      #{job.id}
                    </span>
                  </div>

                  <h3 className="font-medium text-foreground mb-2 line-clamp-2 min-h-[3rem] group-hover:text-primary transition-colors">
                    {job.url}
                  </h3>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-50 mt-4">
                    <div className="flex flex-col">
                      <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Results</span>
                      <span className="text-lg font-bold text-foreground">{job.resultCount}</span>
                    </div>
                    <div className="flex flex-col items-end">
                      <span className="text-xs text-muted-foreground uppercase tracking-wider font-semibold">Created</span>
                      <span className="text-xs font-medium text-foreground">
                        {formatDistanceToNow(new Date(job.createdAt || new Date()), { addSuffix: true })}
                      </span>
                    </div>
                  </div>
                </div>
                
                {job.status === "processing" && (
                  <div className="h-1 w-full bg-slate-100">
                    <div className="h-full bg-primary animate-progress origin-left" />
                  </div>
                )}
              </a>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
