import { useJob } from "@/hooks/use-jobs";
import { Link, useRoute } from "wouter";
import { StatusBadge } from "@/components/StatusBadge";
import { ResultTable } from "@/components/ResultTable";
import { ArrowLeft, Download, RefreshCw, Search, Calendar, Globe, Copy, Check } from "lucide-react";
import { format } from "date-fns";
import { useState } from "react";

export default function JobDetails() {
  const [, params] = useRoute("/jobs/:id");
  const id = parseInt(params?.id || "0");
  const { data: job, isLoading, error } = useJob(id);
  const [copySuccess, setCopySuccess] = useState(false);
  const [showFiltered, setShowFiltered] = useState(false);

  const getFilteredResults = () => {
    if (!job?.results) return [];
    return showFiltered 
      ? job.results.filter(r => r.filtered)
      : job.results.filter(r => !r.filtered);
  };

  const handleDownloadCsv = () => {
    const resultsToExport = getFilteredResults();
    if (!resultsToExport.length) return;

    const headers = ["Place Name", "Website"];
    const rows = resultsToExport.map((r) => [
      `"${r.name.replace(/"/g, '""')}"`,
      r.website || "",
    ]);

    const csvContent = [
      headers.join(","),
      ...rows.map((r) => r.join(",")),
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `google_maps_results_${job.id}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCopyAll = () => {
    const resultsToExport = getFilteredResults();
    if (!resultsToExport.length) return;

    const headers = "Place Name\tWebsite";
    const rows = resultsToExport.map((r) => `${r.name}\t${r.website || ""}`);
    const content = [headers, ...rows].join("\n");

    navigator.clipboard.writeText(content).then(() => {
      setCopySuccess(true);
      setTimeout(() => setCopySuccess(false), 2000);
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="w-12 h-12 border-4 border-primary/20 border-t-primary rounded-full animate-spin" />
            <div className="absolute inset-0 flex items-center justify-center">
              <Search className="w-4 h-4 text-primary" />
            </div>
          </div>
          <p className="text-muted-foreground font-medium animate-pulse">Loading job details...</p>
        </div>
      </div>
    );
  }

  if (error || !job) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full text-center space-y-4">
          <div className="w-16 h-16 bg-destructive/10 text-destructive rounded-full flex items-center justify-center mx-auto mb-6">
            <Search className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold font-display">Job Not Found</h1>
          <p className="text-muted-foreground">
            We couldn't find the scraping job you're looking for. It might have been deleted or the ID is incorrect.
          </p>
          <Link href="/" className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground font-semibold rounded-xl shadow-lg shadow-primary/20 hover:shadow-xl hover:-translate-y-0.5 transition-all">
            <ArrowLeft className="w-4 h-4" />
            Back to Dashboard
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/50 pb-20">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10 backdrop-blur-md bg-white/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/" className="p-2 -ml-2 text-muted-foreground hover:text-foreground hover:bg-slate-100 rounded-lg transition-colors">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="h-6 w-px bg-border hidden sm:block" />
            <h1 className="text-lg font-bold font-display truncate max-w-md hidden sm:block">
              Job #{job.id} Details
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <StatusBadge status={job.status as any} />
            <span className="text-sm text-muted-foreground hidden sm:block">
              {job.resultCount} results found
            </span>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Job Info Card */}
        <div className="bg-white rounded-2xl p-6 border shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-start justify-between gap-6">
            <div className="space-y-4 flex-1">
              <div>
                <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-2">Target URL</h3>
                <div className="flex items-start gap-3 bg-slate-50 p-3 rounded-xl border border-border/50">
                  <Globe className="w-5 h-5 text-blue-500 mt-0.5 shrink-0" />
                  <a 
                    href={job.url} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-sm text-foreground break-all hover:text-primary transition-colors font-mono"
                  >
                    {job.url}
                  </a>
                </div>
              </div>
              
              <div className="flex items-center gap-6 text-sm">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Calendar className="w-4 h-4" />
                  <span>Created {format(new Date(job.createdAt || new Date()), "PPP p")}</span>
                </div>
                {(job.status === "processing" || job.status === "pending") && (
                  <div className="flex items-center gap-2 text-blue-600 animate-pulse">
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span className="font-medium">Live updating...</span>
                  </div>
                )}
              </div>
            </div>

            {/* Stats/Actions */}
            <div className="flex flex-col gap-3 min-w-[200px]">
              <div className="bg-slate-50 rounded-xl p-4 border border-border/50 text-center">
                <div className="text-3xl font-bold font-display text-primary">{job.resultCount}</div>
                <div className="text-xs font-medium text-muted-foreground uppercase tracking-wider mt-1">Total Leads</div>
              </div>
              
              <button
                onClick={handleDownloadCsv}
                disabled={!job.results?.length}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white border-2 border-slate-200 text-slate-700 font-semibold rounded-xl hover:border-primary hover:text-primary disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-slate-200 disabled:hover:text-slate-700 transition-all"
              >
                <Download className="w-4 h-4" />
                Download CSV
              </button>

              <button
                onClick={handleCopyAll}
                disabled={!job.results?.length}
                className={`w-full flex items-center justify-center gap-2 px-4 py-3 font-semibold rounded-xl transition-all ${
                  copySuccess
                    ? "bg-emerald-50 border-2 border-emerald-200 text-emerald-700"
                    : "bg-white border-2 border-slate-200 text-slate-700 hover:border-emerald-500 hover:text-emerald-600 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:border-slate-200 disabled:hover:text-slate-700"
                }`}
              >
                {copySuccess ? (
                  <>
                    <Check className="w-4 h-4" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    Copy All
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Progress Log */}
          {job.progress && (
            <div className="bg-slate-900 rounded-xl p-4 font-mono text-sm text-slate-300 overflow-x-auto border border-slate-800 shadow-inner">
              <div className="flex items-center gap-2 text-emerald-400 mb-2 text-xs uppercase tracking-wider font-bold">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                </span>
                System Log
              </div>
              <p className="whitespace-pre-wrap leading-relaxed">{job.progress}</p>
              {job.error && (
                <div className="mt-4 p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400">
                  <span className="font-bold block mb-1">Error:</span>
                  {job.error}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Results Table */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold font-display flex items-center gap-2">
            Extracted Results
            <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600 text-sm font-medium border border-slate-200">
              {getFilteredResults().length || 0}
            </span>
          </h2>
          <ResultTable results={job.results || []} showFiltered={showFiltered} setShowFiltered={setShowFiltered} />
        </div>
      </main>
    </div>
  );
}
