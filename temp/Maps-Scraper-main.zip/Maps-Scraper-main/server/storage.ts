import { db } from "./db";
import { jobs, results, type Job, type InsertJob, type Result } from "@shared/schema";
import { eq, desc } from "drizzle-orm";

export interface IStorage {
  createJob(job: InsertJob): Promise<Job>;
  getJob(id: number): Promise<(Job & { results: Result[] }) | undefined>;
  getJobs(): Promise<Job[]>;
  updateJobStatus(id: number, status: string, progress?: string, error?: string): Promise<Job>;
  updateJobResultCount(id: number, count: number): Promise<void>;
  addResult(jobId: number, result: { name: string; website: string | null }, filtered?: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db.insert(jobs).values(insertJob).returning();
    return job;
  }

  async getJob(id: number): Promise<(Job & { results: Result[] }) | undefined> {
    const job = await db.query.jobs.findFirst({
      where: eq(jobs.id, id),
      with: {
        results: true,
      },
    });
    return job;
  }

  async getJobs(): Promise<Job[]> {
    return await db.select().from(jobs).orderBy(desc(jobs.createdAt));
  }

  async updateJobStatus(id: number, status: string, progress?: string, error?: string): Promise<Job> {
    const [updated] = await db
      .update(jobs)
      .set({ status, progress, error })
      .where(eq(jobs.id, id))
      .returning();
    return updated;
  }

  async updateJobResultCount(id: number, count: number): Promise<void> {
    await db.update(jobs).set({ resultCount: count }).where(eq(jobs.id, id));
  }

  async addResult(jobId: number, result: { name: string; website: string | null }, filtered: number = 0): Promise<void> {
    await db.insert(results).values({
      jobId,
      name: result.name,
      website: result.website,
      filtered,
    });
  }
}

export const storage = new DatabaseStorage();
