import puppeteer from "puppeteer";
import { storage } from "./storage";

// Random delay between min and max seconds
const delay = (min: number, max: number) => 
  new Promise(resolve => setTimeout(resolve, Math.random() * (max - min) * 1000 + min * 1000));

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
];

// Keywords to filter out
const FILTER_KEYWORDS = [
  "kennel", "dog", "puppy", "pet boarding", "pet grooming", "veterinary",
  "animal shelter", "pet daycare", "canine", "goat farm", "sheep farm",
  "poultry", "chicken farm", "fish farm", "aquaculture", "piggery",
  "vegetable farm", "fruit farm", "organic produce", "greenhouse",
  "nursery", "plant farm", "hydroponics", "floriculture"
];

function isFiltered(text: string): boolean {
  const lower = text.toLowerCase();
  return FILTER_KEYWORDS.some(keyword => lower.includes(keyword.toLowerCase()));
}

export async function startScraping(jobId: number, url: string) {
  let browser;
  try {
    await storage.updateJobStatus(jobId, "processing", "Initializing browser...");

    browser = await puppeteer.launch({
      headless: 'new',
      executablePath: process.env.CHROMIUM_PATH || '/nix/store/zi4f80l169xlmivz8vja8wlphq74qqk0-chromium-125.0.6422.141/bin/chromium-browser',
      args: [
        '--no-sandbox',
        '--disable-setuid-sandbox',
        '--disable-dev-shm-usage',
        '--disable-accelerated-2d-canvas',
        '--disable-gpu',
        '--window-size=1920,1080'
      ]
    });

    const page = await browser.newPage();
    
    // Set random user agent
    const userAgent = USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
    await page.setUserAgent(userAgent);

    await storage.updateJobStatus(jobId, "processing", "Navigating to Google Maps...");
    
    // Navigate with timeout
    await page.goto(url, { waitUntil: 'networkidle2', timeout: 60000 });

    // Check for captcha/consent
    const content = await page.content();
    if (content.includes("Before you continue to Google") || content.includes("consent.google.com")) {
      await storage.updateJobStatus(jobId, "processing", "Handling consent form...");
      try {
        const buttons = await page.$$('button');
        for (const button of buttons) {
          const text = await page.evaluate(el => el.textContent, button);
          if (text?.includes('Accept all') || text?.includes('I agree')) {
            await button.click();
            await page.waitForNavigation({ waitUntil: 'networkidle2' });
            break;
          }
        }
      } catch (e) {
        console.log("No consent button found or click failed, continuing...");
      }
    }

    await storage.updateJobStatus(jobId, "processing", "Scrolling to load results...");

    // Wait a bit more for JavaScript to render
    await delay(2, 3);

    // Find the results feed container with fallback strategies
    let scrollableSelector = '';
    let feedFound = false;
    
    // Try primary selector
    try {
      await page.waitForSelector('div[role="feed"]', { timeout: 5000 });
      scrollableSelector = 'div[role="feed"]';
      feedFound = true;
      console.log("Found results using primary selector: div[role=\"feed\"]");
    } catch (e) {
      console.log("Primary selector failed, trying alternatives...");
    }
    
    // Fallback: Try to find ANY feed-like container
    if (!feedFound) {
      try {
        const containerFound = await page.evaluate(() => {
          // Look for any scrollable container with articles
          const containers = document.querySelectorAll('[role="feed"], div[style*="overflow"]');
          for (const container of containers) {
            const articles = container.querySelectorAll('[role="article"]');
            if (articles.length > 0) {
              return true;
            }
          }
          return false;
        });
        
        if (containerFound) {
          scrollableSelector = '[role="feed"]';
          feedFound = true;
          console.log("Found feed container via article detection");
        }
      } catch (e) {
        console.log("Article detection failed");
      }
    }

    // Last resort: look for any results on the page
    if (!feedFound) {
      try {
        const resultsText = await page.evaluate(() => {
          const bodyText = document.body.innerText;
          return bodyText.includes('hours') || bodyText.includes('phone') || bodyText.includes('website');
        });
        
        if (resultsText) {
          // Page has some Google Maps content, try a generic selector
          scrollableSelector = 'body';
          feedFound = true;
          console.log("Detected Google Maps page with result indicators");
        }
      } catch (e) {
        console.log("Result text detection failed");
      }
    }

    if (!feedFound) {
      // Log page content for debugging
      const pageTitle = await page.title();
      const pageUrl = page.url();
      const pageText = await page.evaluate(() => document.body.innerText.substring(0, 1000));
      const htmlStructure = await page.evaluate(() => {
        const docElement = document.documentElement.outerHTML.substring(0, 2000);
        return docElement;
      });
      console.log(`Page title: ${pageTitle}`);
      console.log(`Page URL: ${pageUrl}`);
      console.log(`Page text preview: ${pageText}`);
      console.log(`HTML structure: ${htmlStructure}`);
      throw new Error("Could not find results list. Make sure the URL is a valid Google Maps search result page with a search query.");
    }

    // Scroll loop
    let previousHeight = 0;
    let noChangeCount = 0;
    let scrollAttempts = 0;
    const maxScrollAttempts = 20;

    while (scrollAttempts < maxScrollAttempts) {
      scrollAttempts++;
      
      // Scroll to bottom - handle different container types
      await page.evaluate((selector) => {
        let element = document.querySelector(selector);
        if (element && selector === 'body') {
          // For body, scroll the window itself
          window.scrollBy(0, window.innerHeight);
        } else if (element) {
          // For specific containers, scroll the container
          element.scrollTo(0, element.scrollHeight);
        }
      }, scrollableSelector);

      // Human-like pause
      await delay(2, 5);

      // Check if height changed
      const newHeight = await page.evaluate((selector) => {
        if (selector === 'body') {
          return document.body.scrollHeight;
        }
        const element = document.querySelector(selector);
        return element ? element.scrollHeight : 0;
      }, scrollableSelector);

      console.log(`Scroll attempt ${scrollAttempts}: height ${previousHeight} -> ${newHeight}`);

      if (newHeight === previousHeight) {
        noChangeCount++;
        // Check for "You've reached the end of the list" text
        const reachedEnd = await page.evaluate(() => {
          return document.body.innerText.includes("You've reached the end of the list");
        });
        
        if (reachedEnd || noChangeCount >= 3) {
          console.log("Reached end of results list");
          break;
        }
      } else {
        noChangeCount = 0;
        previousHeight = newHeight;
      }

      // Extract currently visible items to keep user updated
      const items = await extractItems(page);
      await storage.updateJobStatus(jobId, "processing", `Found ${items.length} items so far...`);
    }
    
    console.log(`Scrolling completed after ${scrollAttempts} attempts`);

    await storage.updateJobStatus(jobId, "processing", "Extracting final data...");

    // Final extraction
    const items = await extractItems(page);
    
    // Save items
    let savedCount = 0;
    const uniqueItems = new Set(); // Use name+website as key to avoid duplicates
    
    for (const item of items) {
      const key = `${item.name}|${item.website}`;
      if (!uniqueItems.has(key)) {
        uniqueItems.add(key);
        const filtered = isFiltered(item.name);
        await storage.addResult(jobId, item, filtered ? 1 : 0);
        savedCount++;
      }
    }

    await storage.updateJobResultCount(jobId, savedCount);
    await storage.updateJobStatus(jobId, "completed", "Completed successfully");

  } catch (error: any) {
    console.error("Scraping error:", error);
    await storage.updateJobStatus(jobId, "failed", undefined, error.message);
  } finally {
    if (browser) {
      await browser.close();
    }
  }
}

async function extractItems(page: any) {
  return await page.evaluate(() => {
    const results: any[] = [];
    let articles: NodeListOf<Element> | null = null;
    
    // Try primary selector
    articles = document.querySelectorAll('div[role="feed"] > div > div[role="article"]');
    
    // Fallback if primary selector didn't find anything
    if (articles.length === 0) {
      articles = document.querySelectorAll('div[role="article"]');
    }
    
    // Another fallback - look for elements with specific classes
    if (articles.length === 0) {
      articles = document.querySelectorAll('[data-testid*="item"], [class*="result"], [class*="listing"]');
    }
    
    // Last resort: look for divs with aria-labels that look like place names
    if (articles.length === 0) {
      const allElements = document.querySelectorAll('[aria-label]');
      articles = Array.from(allElements).filter((el) => {
        const label = el.getAttribute('aria-label') || '';
        // Simple heuristic: looks like a place name (has comma, or common business words)
        return label.length > 3 && (label.includes(',') || label.includes('·') || label.toLowerCase().includes('reviews'));
      }) as any;
    }

    const seenNames = new Set();
    
    for (const article of articles) {
      try {
        // Name is usually in a specific aria-label or heading
        let ariaLabel = article.getAttribute('aria-label');
        
        // If no aria-label, try to extract from text content
        if (!ariaLabel) {
          const heading = article.querySelector('h2, h3, h4, [role="heading"]');
          if (heading) {
            ariaLabel = heading.textContent?.trim() || null;
          }
        }
        
        if (!ariaLabel || ariaLabel.length < 2) continue;
        
        // Avoid duplicates
        if (seenNames.has(ariaLabel)) continue;
        seenNames.add(ariaLabel);

        // Website: Look for links with "Website" text or specific icons
        let website = null;
        const links = article.querySelectorAll('a');
        for (const link of links) {
          const href = link.href;
          const text = link.innerText;
          const aria = link.getAttribute('aria-label') || '';
          
          // Heuristic: Link that goes to a non-google URL or has "Website" aria label
          if (aria.includes('Website') || text.includes('Website') || aria.includes('website')) {
             website = href;
             break;
          }
        }
        
        // Clean up website URL if it's a google redirect
        if (website && website.includes('google.com/url')) {
           try {
             const urlObj = new URL(website);
             website = urlObj.searchParams.get('q') || website;
           } catch (e) {}
        }

        results.push({
          name: ariaLabel,
          website: website
        });
      } catch (e) {
        // Skip malformed items
      }
    }
    return results;
  });
}
