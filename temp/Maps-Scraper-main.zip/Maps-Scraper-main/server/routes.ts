import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { startScraping } from "./scraper";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post(api.jobs.create.path, async (req, res) => {
    try {
      console.log("Creating job with body:", req.body);
      let input = api.jobs.create.input.parse(req.body);
      
      // Normalize URL - ensure it has https:// protocol
      if (!input.url.startsWith('http://') && !input.url.startsWith('https://')) {
        input.url = 'https://' + input.url;
      }
      
      // Validate it's a valid Google Maps URL
      if (!input.url.includes('google.com/maps')) {
        return res.status(400).json({
          message: 'Please provide a valid Google Maps search URL',
          field: 'url',
        });
      }
      
      const job = await storage.createJob(input);
      console.log("Job created successfully:", job.id);
      
      // Start scraping in background
      startScraping(job.id, job.url).catch(err => {
        console.error(`Error in background scraper for job ${job.id}:`, err);
      });
      
      res.status(201).json(job);
    } catch (err) {
      console.error("Job creation error:", err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({
          message: err.errors[0].message,
          field: err.errors[0].path.join('.'),
        });
      }
      res.status(500).json({ message: err instanceof Error ? err.message : "Internal Server Error" });
    }
  });

  app.get(api.jobs.get.path, async (req, res) => {
    const job = await storage.getJob(Number(req.params.id));
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }
    res.json(job);
  });

  app.get(api.jobs.list.path, async (req, res) => {
    const jobs = await storage.getJobs();
    res.json(jobs);
  });

  return httpServer;
}
